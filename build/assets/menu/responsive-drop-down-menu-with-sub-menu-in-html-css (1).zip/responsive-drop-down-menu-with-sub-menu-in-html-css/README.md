# Responsive Drop Down Menu with Sub Menu in HTML & CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/fadzrinmadu/pen/KKWBgqZ](https://codepen.io/fadzrinmadu/pen/KKWBgqZ).

Responsive drop down menu with sub menu in html and css reference from youtube CodingLab